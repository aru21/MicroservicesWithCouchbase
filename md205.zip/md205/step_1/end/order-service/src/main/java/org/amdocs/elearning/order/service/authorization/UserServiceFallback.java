package org.amdocs.elearning.order.service.authorization;

import java.time.LocalDate;

import org.amdocs.elearning.order.service.user.User;
import org.amdocs.elearning.order.service.user.UserType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

@Component
public class UserServiceFallback implements UserServiceClient {
	public static final User UNCONFIRMED_USER = new User("UNCONFIRMED_USER_ID","NotApplicable","NotApplicable","NotApplicable",UserType.PATRON,LocalDate.MIN);
	public User getUserByID(@PathVariable("userID") String userID) {
		return UNCONFIRMED_USER;
	}
}
