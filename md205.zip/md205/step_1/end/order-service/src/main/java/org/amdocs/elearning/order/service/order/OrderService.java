package org.amdocs.elearning.order.service.order;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;

public class OrderService {

	private OrderIDGenerator orderIDGenerator;
	private OrderDAO orderDAO;

	@Autowired
	public OrderService(OrderDAO orderDAO, OrderIDGenerator orderIDGenerator) {
		this.orderDAO = orderDAO;
		this.orderIDGenerator = orderIDGenerator;
	}

	public Order placeOrder(final OrderDetails orderDetails, String orderStatus) {
		final UUID orderID = orderIDGenerator.getNextID();
		final LocalDateTime orderDate = LocalDateTime.now();
		final Order order = new Order(orderID, orderDate, orderStatus, orderDetails);
		orderDAO.save(order);

		return order;
	}

	public void cancelOrder(final String orderID) {
		orderDAO.deleteOrder(UUID.fromString(orderID));
	}

	public List<Order> getAllOrders() {
		List<Order> orders = new ArrayList<Order>();
		Iterable<Order> ordersFromDAO = orderDAO.getOrders();
		ordersFromDAO.forEach(orders::add);
		return orders;
	}

	public Optional<Order> getOrderById(final String orderID) {
		return orderDAO.findById(UUID.fromString(orderID));
	}
}