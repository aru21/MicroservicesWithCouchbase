package org.amdocs.elearning.order.service.authorization;

import org.amdocs.elearning.order.service.user.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "user-service", fallback = UserServiceFallback.class)
public interface UserServiceClient {
	@RequestMapping(method = RequestMethod.GET, value = "/users/{userID}")
	User getUserByID(@PathVariable("userID") String userID);
}