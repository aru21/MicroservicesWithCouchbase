package org.amdocs.elearning.order.service.order;


import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.amdocs.elearning.order.service.authorization.UserAuthService;
import org.amdocs.elearning.order.service.authorization.UserServiceFallback;
import org.amdocs.elearning.order.service.user.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/orders")
public class OrdersController {
    private final OrderService orderService;
    private final UserAuthService userAuthService;

    @Autowired
    public OrdersController(final OrderService orderService, final UserAuthService userAuthService){
        this.orderService = orderService;
        this.userAuthService = userAuthService;
    }

    @RequestMapping(path = {"/", ""}, method = RequestMethod.GET)
    public ResponseEntity<List<Order>> getAllOrders(@RequestHeader(value="userID") String userID) {
        Optional<?> validatedUser = userAuthService.validateUserByID(userID);

        if(validatedUser.isPresent()) {
            return new ResponseEntity<>(orderService.getAllOrders(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }

    @RequestMapping(method = RequestMethod.POST, headers="Accept=application/json")
    public ResponseEntity<Order> placeOrder(@RequestHeader(value="userID") String userID,
                                            @Valid @RequestBody OrderDetails orderDetails) {
        Optional<User> validatedUser = userAuthService.validateUserByID(userID);

        if (validatedUser.isPresent()) {
        	String orderStatus = "PENDING";
        	if (validatedUser.get() == UserServiceFallback.UNCONFIRMED_USER )
        	{
        		orderStatus = "UNCONFIRMED";
        	}

            final Order placeOrder = this.orderService.placeOrder(orderDetails, orderStatus);

            return new ResponseEntity<>(placeOrder, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }

    @RequestMapping(path = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<Order> getOrderByID(@RequestHeader(value="userID") String userID, @PathVariable final String id) {

        Optional<?> validatedUser = userAuthService.validateUserByID(userID);

        if (validatedUser.isPresent()) {
            final Optional<Order> orderOptional = this.orderService.getOrderById(id);

            return orderOptional.isPresent() ?
                    new ResponseEntity<>(orderOptional.get(), HttpStatus.OK) :
                    new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }

}