package org.amdocs.elearning.order.service.order;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Optional;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class OrderServiceTest {
	
	private final static UUID UID1 = UUID.fromString("00000001-0000-0000-0000-000000000000");
	
    private OrderDetails mockOrderDetails = new OrderDetails("eventTitle", LocalDateTime.now(), "venue1", 2);
    private OrderService orderService;
    private OrderDAO mockDAO;

    @Before
    public void setup()
    {
    	mockDAO = Mockito.mock(OrderDAO.class);
    	orderService = new OrderService(mockDAO,new SequentialOrderIDGenerator());
    }
    @Test
    public void placeOrder() {
        final Order order = orderService.placeOrder(mockOrderDetails,"PENDING");

        Mockito.verify(mockDAO).save(order);
        Assert.assertNotNull(order);
        Assert.assertEquals(order.getEventName(), "eventTitle");
        Assert.assertNotNull(order.getEventDate());
        Assert.assertNotNull(order.getOrderDate());
        Assert.assertEquals("00000001-0000-0000-0000-000000000000",order.getOrderId().toString());
        Assert.assertEquals(order.getVenue(), mockOrderDetails.getVenue());
        Assert.assertEquals(order.getNumberOfTickets(), mockOrderDetails.getNumberOfTickets());
        Assert.assertEquals(order.getOrderStatus(), "PENDING");
    }

    @Test
    public void cancelOrder() {

        orderService.cancelOrder(UID1.toString());
        Mockito.verify(mockDAO).deleteOrder(UID1);
    }

    @Test
    public void getAllOrders() {

        Assert.assertEquals(orderService.getAllOrders().size(), 0);

        HashSet<Order> ordersSet = new HashSet<Order>();
        ordersSet.add(new Order(UID1,null,"PENDING",mockOrderDetails));
        ordersSet.add(new Order(UUID.fromString("00000002-0000-0000-0000-000000000000"),null,"PENDING",mockOrderDetails));
    	Mockito.when(mockDAO.getOrders()).thenReturn(ordersSet);
        
        Assert.assertEquals(2, orderService.getAllOrders().size());
    }

    @Test
    public void getOrderById_withCorrectID() {
    	Order mockOrder = new Order();
    	Mockito.when(mockDAO.findById(UID1)).thenReturn(Optional.of(mockOrder));
        Assert.assertEquals(orderService.getOrderById(UID1.toString()), Optional.of(mockOrder));
    }

    @Test
    public void getOrderById_withIncorrectID() {
        Assert.assertFalse(orderService.getOrderById("00000001-0000-0000-0000-000000000000").isPresent());
    }
}