# MD205 - Step 1: Implementing Circuit Breaking With Hystrix

In the previous chapter you learned about Message Queues and added message communication between **order-service** and **user-service**.  

In this chapter, Circuit Breaking with Hystrix, you will learn how to improve the fault tolerance and responsiveness of your microservices using a cloud pattern called circuit breaking, and implement it using the Hystrix library.

In this first step you will add Hystrix support to **order-service** so that it can function and take orders even when **user-service** is slow or crashed. 

_**Need to go back to the previous step?** In the Terminal, enter `git checkout step_0` and then refresh your browser._

---

## Microservices ,Faults and Tolerance 

Microservices applications can suffer when one of the services in the application is slow or crashed. All other services that call the faulty service will also become slow, and so will the services that call those services and so on.  This can cause a chain reaction that slows down the entire system, making it unresponsive.

## Circuit Breaking, Fail Fast and Fallback

When a faulty service slows down the system, it is important to isolate it from the rest of the system. Two options that we have is

* Quickly recognize that the service is not responsive and return an error  (*fail fast*)
* Recognize that the service is not responsive and return a default value instead ( *fallback* )

This common pattern of programming distributed applications is called *Circuit Breaking*, just like the electrical circuit breaker in a house prevents one faulty electric device from causing a power surge that would damage the rest of the electrical appliances.

![circuit-breaking](images/circuit-breaking.png)

## Hystrix

You will implement circuit breaking using the Hystrix fault tolerance library. Hystrix was originally written by Netflix and is now part of Spring Cloud.

### Tripping and Resetting Circuit Breakers

Hystrix can identify when a service is slow or not responding, and either make the call fail fast or return a response from a predefined fallback method - but this is not all it will do. When Hystrix identifies a failing service, it will *trip* the circuit breaker for that service and keep it *open*. That means that the next few calls the application will try to make to the service will immediately return with an error or fallback. After a period of time, Hystrix will test the failing service again by letting one call actually go through to it, and if that call is successful, Hystrix will reset the circuit breaker back to its normal state.

### Hystrix Command Classes vs. Annotations

Telling Hystrix to add Circuit Breaking for a service call is done using Hystrix commands.  You can do this by creating command classes, or by placing annotations on method calls.

For example let's look at a microservice to microservice call that can fail. In Ticket Monster, **order-service** calls **user-service** for authenticating a user by calling the Feign `UserServiceClient` interface, like this:

```java
@FeignClient(name = "user-service")
public interface UserServiceClient {
	@RequestMapping(method = RequestMethod.GET, value = "/users/{userID}")
	User getUserByID(@PathVariable("userID") String userID);
}
```

```java
    public Optional<User> validateUserByID(String userID) {
        try{        	
        	User user = userServiceClient.getUserByID(userID);
```

The `getUserByID` call may be hung or slow if there is a problem with **user-service** . To make this call fail immediately we can use a Hystrix command, or Hystrix annoation.

To use a Hystrix command class we would inherit from `HystrixCommand` and call `getUserByID` in the command's `run()` method:

```java
class UserAuthHystrixCommand extends HystrixCommand<User> {

	private UserServiceClient userServiceClient;
	private String userID;

    public UserAuthHystrixCommand(UserServiceClient userServiceClient,String userID) {
        super(HystrixCommandGroupKey.Factory.asKey("orderServiceHystrixCommandGroup"));
        this.userServiceClient = userServiceClient;
        this.userID = userID;
    }

    @Override
    protected User run() {
    	User user = userServiceClient.getUserByID(userID);
    	return user;
    }

    @Override
    protected User getFallback() {
        return UserServiceFallback.UNCONFIRMED_USER;
    }
}

```

and then we would use it in `validateUserByID` by changing it as follows:

```java
public Optional<User> validateUserByID(String userID) {
    try{
    	
    	//User user = userServiceClient.getUserByID(userID);
    	UserAuthHystrixCommand userAuthHystrixCommand = new UserAuthHystrixCommand(userServiceClient, userID);
    	User user = userAuthHystrixCommand.execute();
```
Using command classes has quite a few advantages:

* You can give the commands names, and group them with group names, so that you can later monitor which commands failed using a tool called the Hystrix Dashboard
*  You can use commands to use the result of the last successful call as the fallback value for a failing service
* You can use them to setup a callback for being notified when a long running command completes.
* If you want to use Hystrix's advanced features like command collapsing, you need to write custom commands.

However, commands are quite verbose, and you have to write quite a bit of code. We could achieve the same result as the code above by just placing an annotation on the Feign interface, and defining a fallback method that should be called when the service fails:

```java
@FeignClient(name = "user-service", fallback = UserServiceFallback.class)
public interface UserServiceClient {
	@RequestMapping(method = RequestMethod.GET, value = "/users/{userID}")
	User getUserByID(@PathVariable("userID") String userID);
}
```

```java
@Component
public class UserServiceFallback implements UserServiceClient {
	public static final User UNCONFIRMED_USER = new User("UNCONFIRMED_USER_ID","NotApplicable","NotApplicable","NotApplicable",UserType.PATRON,LocalDate.MIN);
	public User getUserByID(@PathVariable("userID") String userID) {
		return UNCONFIRMED_USER;
	}
}
```

If we were not using Feign, we would just place the `@HystrixCommand` annotation on the method that calls the service:

```java
    @HystrixCommand(fallbackMethod = "getUnconfirmedUser")
    public User getUserByID(@PathVariable("userID") String userID) {
        User user = restTemplate.exchange("http://localhost:8080/users/{userID}...
    }                 
    public User getUnconfirmedUser() { return UserServiceFallback.UNCONFIRMED_USER; }                                   
```

In your exercise you will use an annotation parameter on the Feign interface rather than custom command classes.

## Hystrix Open Circuit Configuration

Hystrix allows you to configure when and for how long it trips a circuit breaker and keeps the circuit open.

Hystrix monitors the calls using a window size of `metrics.rollingStats.timeInMilliseconds`. If during that time window at least  `circuitBreaker.errorThresholdPercentage`  ( 50% by default ) of the calls fail, and at least  `circuitBreaker.requestVolumeThreshold` calls ( 20 by default ) were made to the service,  Hystrix will open the circuit, no other request will be passed to the service, and instead an error or fallback response will be served back. The circuit will stay open like this for the next `circuitBreaker.sleepWindowInMilliseconds` milliseconds.

You can configure these in the **application.properties** file. For example:

```properties
hystrix.command.default.circuitBreaker.requestVolumeThreshold=20
hystrix.command.default.circuitBreaker.errorThresholdPercentage=50
hystrix.command.default.circuitBreaker.sleepWindowInMilliseconds=5000
hystrix.command.default.metrics.rollingStats.timeInMilliseconds=30000
```



## Watch a Slow Service Affect Its Caller

Now it's hands on time. Before we see how to solve latency issues with Hystrix, first let's see how a slow service affects the overall performance of a Microservices application, and see how it slows down the services that call it. To artificially introduce a delay, you will make **user-service** try to read from the keyboard when it is called.

### Introduce a Delay into User-Service

#### Modify UserController's getUser function:

Add the following code to **user-service** `UserController` `getUser` function, to read from the keyboard:

```java
    //...
	public ResponseEntity<User> getUser(@ApiParam("Id of the user to get") @PathVariable final String id) {

    
    	try {
			System.in.read();
		} catch (IOException e) {
			e.printStackTrace();
		}
```

Add the necessary import to make the code compile.

##### What do these changes do?

We want to simulate **user-service** being slow when **order-service** calls its `getUser` function to authenticate users, so we add the `System.in.read()` call, which will make user-service wait indefinitely. This call can throw an `IOException` which we must handle.

### Give Order-Service Longer Timeouts

#### Modify order-service application.properties

Add the following properties to **order-service**'s **application.properties** file

```properties
feign.client.config.default.connectTimeout=5000
feign.client.config.default.readTimeout=5000
```

##### What do these changes do?

We want to show what happens when you call a slow service and you don't have Hystrix. However, we are using Feign in order service, and Feign also has service call timeouts of its own. To really see the delay caused by calling a slow service, we increase the Feign timeouts. 

### Temporarily Disable UserController Tests

#### Modify user-service UserControllerTest

Comment out the @Test line in all of **user-service** `UserControllerTest` class EXCEPT `createUser`

```java
	//@Test
	public void getUserById_Match() {
...
    //@Test
	public void getUserById_NoMatch() {
...
	@Test
	public void createUser() {
...
	//@Test
	public void updateUser() {
...
	//@Test
	public void deleteUser() {

```

##### What do these changes do?

We want to show what happens when you call a slow service and you don't have Hystrix so we stopped execution in `UserController` `getUser`with a read from the keyboard.  However, this will also pause the many different tests calling this code, and the build won't be able to complete. To avoid this, we temporarily disable these tests by commenting out the @Test annotations. However, the test class needs at least one @Test annotation to be present, or Maven will fail the build, so we leave the `createUser` test active, since it does not call `getUser`.

### Temporarily Disable Integration Tests

#### Modify user-service UserIntegrationTest

Comment out the @Test line in all of **user-service** `UserIntegrationTest` class EXCEPT `createUser`

```java
	//@Test
	public void deleteUserSendsMessage() throws Exception {
...
    //@Test
	public void getUserById_Match() throws Exception {
...
	//@Test
	public void getUserById_NoMatch() throws Exception {
...
	@Test
	public void createUser() throws Exception {
...
    //@Test
	public void updateUser() throws Exception {
...
    //@Test
	public void deleteUser() throws Exception {

```

##### What do these changes do?

Again, we want to show what happens when you call a slow service and you don't have Hystrix so we stopped execution in `UserController` `getUser`with a read from the keyboard.  However, this will also pause the many different tests calling this code, and the build won't be able to complete. To avoid this, we temporarily disable these tests by commenting out the @Test annotations. However, the test class needs at least one @Test annotation to be present, or Maven will fail the build, so we leave the `createUser` test active, since it does not call `getUser`.



## Building and Running

Now let's check that the **order-service** really gets slowed down by a slow **user-service**. 

### Make Sure that All Required Tools are Running

Since in previous chapters you added messaging and database support to Ticket Monster, **user-service** and **order-service** now depend on Kafka, Zookeeper, and Couchbase to be running in order to work. If they are not, or you are not sure, read through the previous steps to see how to check if they are running, and how to start them if they are not.

If **user-service** or **order-service** are running, make sure you stop them before building.

Make sure you save all of your work.

### Build the User Service

**Note:** Because the **order-service** build runs an integration test that uses the same port as the production user-service if **user-service** is running when we build **order-service**, the build will fail. You need to first build the two services, and then run them.

1. In the Terminal, change to the **md205/sandbox/user-service** directory.

2. Package the application with: `mvn clean package`

   Make sure that all the unit and integration tests passed, that there were no failures or errors, and that Maven terminated with a `[INFO] BUILD SUCCESS` message

### Build the Order Service

1. In another Terminal, change to the **md205/sandbox/order-service** directory.

2. Package the application with: `mvn clean package`

   Make sure that all the unit and integration tests passed, that there were no failures or errors, and that Maven terminated with a `[INFO] BUILD SUCCESS` message

### Run the User Service

In the terminal where you built it, run the **user-service** with: `java -jar target/user-service-md205-0.1.0.jar`

### Run the Order Service

In the terminal where you built it, run the **order-service** with: `java -jar target/order-service-md205-0.1.0.jar`

### Try to Place an Order

Leave the servers running in their Terminal windows, and open a new Terminal window. In the new Terminal, enter the following command that will be sent to **order-service**:

```
$ curl -i -H "Content-Type: application/json" -H "userID: 0" -d '{"eventName": "Event1", "venue": "Venue1", "eventDate": "2020-05-02T20:00:00", "numberOfTickets": 2}' http://localhost:8080/orders

```

There should be no response for 5 seconds. Then you should see output similar to the following:

```
{"timestamp":"2019-05-17T08:42:00.492+0000","status":500,"error":"Internal Server Error","message":"Read timed out executing GET http://user-service/users/0","path":"/orders"}

```

The **order-service** tried to create an order for user 0, so it called **user-service** to see if that is a valid user. But **user-service** is stuck trying to read from the keyboard, so it does not respond. Even without Hystrix, **order-service** has timeouts because it uses Feign to call **user-service**. You modified the Feign connection to timeout after 5 seconds, and then we get the error.

This demonstrates how one slow service can slow down the entire application.

## Implement Fail Fast With Hystrix

Now let's add Circuit Breaking and make calls to slow services fail quickly using Hystrix.

### Make Order-Service use Hystrix

#### Modify the POM

Add the following dependencies to the **order-service** **pom.xml**

```xml
		<dependency>
			<groupId>org.springframework.cloud</groupId>
			<artifactId>spring-cloud-starter-netflix-hystrix</artifactId>
		</dependency>

		<dependency>
			<groupId>org.springframework.cloud</groupId>
			<artifactId>spring-cloud-starter-hystrix-dashboard</artifactId>
			<version>1.4.6.RELEASE</version>
		</dependency>
```

##### What do these changes do?

The `spring-cloud-starter-netflix-hystrix` dependency adds Hystrix support to the project. Although some of the Hystrix jar files were already added to the project by the Ribbon starter dependency, Hystrix would not function correctly without this new dependency.

The `spring-cloud-starter-hystrix-dashboard` dependency adds support for Hystrix's dashboard, which lets you monitor the state of circuits visually. **Note:** The dashboard also requires the actuator dependency, but that is already included in the project.

#### Enable Hystrix Circuit Breaking

Add the `@EnableCircuitBreaker` to the annotations on **order-service**'s `Application` class. Add the necessary import as well.

```java
@SpringBootApplication()
@EnableFeignClients
@EnableCircuitBreaker
@EnableHystrixDashboard
@EnableBinding(Sink.class)
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```

Add the necessary import for the annotation.

##### What do these changes do?

The `@EnableCircuitBreaker` annotation enables Hystrix's Circuit Breaking feature, and makes calls to a slow service fail immediately or return a pre-defined fall-back response.

`@EnableHystrixDashboard` will let us monitor the circuit breaking operations as they happen using the Hystrix Dashboard tool.

#### Enable Feign To Use Hystrix

Add the following properties to **order-service**'s **application.properties** file

```properties
feign.hystrix.enabled=true
hystrix.command.default.circuitBreaker.requestVolumeThreshold=2
hystrix.command.default.circuitBreaker.errorThresholdPercentage=50
hystrix.command.default.circuitBreaker.sleepWindowInMilliseconds=5000
hystrix.command.default.metrics.rollingStats.timeInMilliseconds=30000
```

##### What do these changes do?

This line `feign.hystrix.enabled=true` enable Feign to use Hystrix for timeouts

`hystrix.command.default.metrics.rollingStats.timeInMilliseconds=30000`,  `hystrix.command.default.circuitBreaker.requestVolumeThreshold=2` , and `hystrix.command.default.circuitBreaker.errorThresholdPercentage=50`  enable opening the circuit after two timed-out calls that come within 30 seconds of each other, where at least 50% (one) of them fail.

`hystrix.command.default.circuitBreaker.sleepWindowInMilliseconds=5000` says that the circuit will be left open for 5 seconds.

## Building and Running

Now let's check that the **order-service** really gets an immediate failure message from **user-service**. 

### Make Sure that All Required Tools are Running

Since in previous chapters you added messaging and database support to Ticket Monster, **user-service** and **order-service** now depend on Kafka, Zookeeper, and Couchbase to be running in order to work. If they are not, or you are not sure, read through the previous steps to see how to check if they are running, and how to start them if they are not.

If **user-service** or **order-service** are running, make sure you stop them before building.

### Build the User Service

**Note:** Because the order-service build runs an integration test that uses the same port as the production user-service if user-service is running when we build order-service, the build will fail. You need to first build the two services, and then run them.

1. In the Terminal, change to the **md205/sandbox/user-service** directory.

2. Package the application with: `mvn clean package`

   Make sure that all the unit and integration tests passed, that there were no failures or errors, and that Maven terminated with a `[INFO] BUILD SUCCESS` message

### Build the Order Service

1. In another Terminal, change to the **md205/sandbox/order-service** directory.

2. Package the application with: `mvn clean package`

   Make sure that all the unit and integration tests passed, that there were no failures or errors, and that Maven terminated with a `[INFO] BUILD SUCCESS` message

### Run the User Service

In the terminal where you built it, run the **user-service** with: `java -jar target/user-service-md205-0.1.0.jar`

### Run the Order Service

In the terminal where you built it, run the **order-service** with: `java -jar target/order-service-md205-0.1.0.jar`

### Try to Place an Order

Leave the servers running in their Terminal windows, and open a new Terminal window. In the new Terminal, enter the following command that will be sent to **order-service**:

```
$ curl -i -H "Content-Type: application/json" -H "userID: 0" -d '{"eventName": "Event1", "venue": "Venue1", "eventDate": "2020-05-02T20:00:00", "numberOfTickets": 2}' http://localhost:8080/orders

```

This time there should be no 5 second delay. Instead after a short time, perhaps a second, you should see the timeout error:

```
{"timestamp":"2019-05-17T09:56:01.700+0000","status":500,"error":"Internal Server Error","message":"UserServiceClient#getUserByID(String) timed-out and no fallback available.","path":"/orders"}

```

The **order-service** tried to create an order for user 0, so it called **user-service** `getUserByID` to see if that is a valid user. But **user-service** is stuck trying to read from the keyboard, so it does not respond. When the service does not respond longer than the Hystrix default timeout, Hystrix takes over.

There is no fallback defined, so Hystrix generates an error which makes the call to `user-service` fail fast. You can see this in the response:

> timed-out and no fallback available

In many scenarios receiving a quick error response is preferable to slow or no response.

This demonstrates how using Hystrix you can isolate slow services and avoid having them slow down the entire application.

### Watch the Cicuit Open and Close

If you keep placing calls after that, the circuit should be open, and you should get a much faster error response, and see a different error code, indicating that Hystrix short circuited the call:

```shell
$ curl -i -H "Content-Type: application/json" -H "userID: 0" -d '{"eventName": "Event1", "venue": "Venue1", "eventDate": "2020-05-02T20:00:00", "numberOfTickets": 2}' http://localhost:8080/orders
HTTP/1.1 500
Content-Type: application/json;charset=UTF-8
Transfer-Encoding: chunked
Date: Tue, 21 May 2019 13:28:08 GMT
Connection: close

{"timestamp":"2019-05-21T13:28:08.102+0000","status":500,"error":"Internal Server Error","message":"UserServiceClient#getUserByID(String) short-circuited and no fallback available.","path":"/orders"}

```

If you wait 5 seconds for the circuit to close, and then issue the command again, it should be a little slower again, giving you the service timed out message again.

```
$ curl -i -H "Content-Type: application/json" -H "userID: 0" -d '{"eventName": "Event1", "venue": "Venue1", "eventDate": "2020-05-02T20:00:00", "numberOfTickets": 2}' http://localhost:8080/orders
HTTP/1.1 500
Content-Type: application/json;charset=UTF-8
Transfer-Encoding: chunked
Date: Tue, 21 May 2019 13:30:15 GMT
Connection: close

{"timestamp":"2019-05-21T13:30:15.662+0000","status":500,"error":"Internal Server Error","message":"UserServiceClient#getUserByID(String) timed-out and no fallback available.","path":"/orders"}

```

**Note:**

If you would like to see how the application acts when **user-service** is working fast again, press ENTER a few times in the Terminal window where you ran it. This will release **user-service** from waiting for `System.in.read();` and enable `getUser` to complete.

## Monitor with the Hystrix Dashboard

Now let's watch the state of the circuits using Hystrix's monitoring tool, the Hystrix Dashboard.

**Note:** It is important to point out that the **hystrix-dashboard has been deprecated** because of what Netflix felt were security issues.

First make sure **user-service** and **order-service** are still running, and run them again if they are not.

In Firefox, browse to the following URL http://localhost:8080/hystrix

The dashboard can monitor several Hystrix streams. In the top text field, found just under the Hystrix Dashboard title, enter the name of the stream: http://localhost:8080/actuator/hystrix.stream

Your browser page should look something like this:

![Hystrix Dashboard Initial](images/hystrix-dashboard.png)

Now click **Monitor Stream**.

Try placing some orders to **order-service** and observing the statistics in the dashboard. Occasionally try pressing enter in the Terminal where you ran **user-service** to get some successful calls.

Your browser page should look something like this:

![Hystrix Stream](images/hystrix-dashboard-stream.png)

Here is a brief explanation of the dashboard statistics:

`getUserByID` is our service call that has an associated Hystrix command.

The dashboard shows **Circuit Open** or **Circuit Closed** according to the state of the circuit.

The green number is the number of successful calls that have been made during the last rolling statistics window period, and the yellow number is the number of timed-out ones. The blue number is the number of calls that were short circuited.

Here are explanations of some other stats:

![Dashboard Explanations](images/dashboard-annoted-circuit-640.png)

## Implement Fallback With Hystrix

Now let's make calls to slow services return a fallback response quickly using Hystrix.

### Slow Authentication Logic For Order Service

As previously mentioned, when `placeOrder` is called , **order-service** calls the **user-service** controller's `getUserByID` function to see if an order is for a valid user. Let's decide that we don't want **order-service** to wait for a slow **user-service** , but still wants to complete the order placement without an error.

Our solution will be that when **user-service** is not responding we will place the order anyway but with a status of `UNCONFIRMED` instead of `PENDING`.

### Make Order-Service use Hystrix Fallbacks

#### Modify the Feign Interface

Change the `FeignClient` annotation on the **order-service** `UserServiceClient` interface to this:

```java
@FeignClient(name = "user-service", fallback = UserServiceFallback.class)
```

##### What do these changes do?

The `fallback` attribute defines the class that will contain the pre-defined fallback values in case the call to **user-service** `getUserByID` is slow. To call **user-service** we are using a Feign interface that could have many different function calls, so we specify that the `UserServiceFallback` class will have the fallback values for all the functions.

#### Specify the Fallback Values

Create a new class in the **order-service** `org.amdocs.elearning.order.service.authorization` package called `UserServiceFallback` 

```java
package org.amdocs.elearning.order.service.authorization;

import java.time.LocalDate;

import org.amdocs.elearning.order.service.user.User;
import org.amdocs.elearning.order.service.user.UserType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

@Component
public class UserServiceFallback implements UserServiceClient {
	public static final User UNCONFIRMED_USER = new User("UNCONFIRMED_USER_ID","NotApplicable","NotApplicable","NotApplicable",UserType.PATRON,LocalDate.MIN);
	public User getUserByID(@PathVariable("userID") String userID) {
		return UNCONFIRMED_USER;
	}
}

```

##### What do these changes do?

The new `UserServiceFallback` class defines the value that will be returned when the service call is slow, for each of the functions in the Feign interface `UserServiceClient`

When the `getUserByID` call to **user-service** is slow our fallback will be to return  a special dummy `User` value, `UNCONFIRMED_USER` , that will serve to indicate to **order-service** that authentication was not complete because of a timeout. 

We define `UNCONFIRMED_USER`as a `public static` variable on the class itself, so that other code in order-service can read it.

#### Place Orders by Unauthenticated Users as UNCONFIRMED

Change the **order-service** `OrdersController`  `placeOrder`  function to look like this:

```java
    @RequestMapping(method = RequestMethod.POST, headers="Accept=application/json")
    public ResponseEntity<Order> placeOrder(@RequestHeader(value="userID") String userID,
                                            @Valid @RequestBody OrderDetails orderDetails) {
        Optional<User> validatedUser = userAuthService.validateUserByID(userID);

        if (validatedUser.isPresent()) {
        	String orderStatus = "PENDING";
        	if (validatedUser.get() == UserServiceFallback.UNCONFIRMED_USER )
        	{
        		orderStatus = "UNCONFIRMED";
        	}

            final Order placeOrder = this.orderService.placeOrder(orderDetails, orderStatus);

            return new ResponseEntity<>(placeOrder, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }
```

##### What do these changes do?

The `OrdersController` `placeOrder` code uses `userAuthService.validateUserByID` to call the `user-service` and get the user for the order.  Earlier you configured Hystrix to return `UserServiceFallback.UNCONFIRMED_USER` if there is a timeout.  If that is the returned value, then we place the order with an `UNCONFIRMED` status instead of the usual `PENDING` status.

Add the necessary missing imports.

#### Make Order Service Accept Order Status as a Parameter

Change the **order-service** `OrderService` `placeOrder`  function to look like this:

```java
	public Order placeOrder(final OrderDetails orderDetails, String orderStatus) {
		final UUID orderID = orderIDGenerator.getNextID();
		final LocalDateTime orderDate = LocalDateTime.now();
		final Order order = new Order(orderID, orderDate, orderStatus, orderDetails);
		orderDAO.save(order);

		return order;
	}
```

##### What do these changes do?

Now that the order may sometimes be placed with an `UNCONFIRMED` status instead of the usual `PENDING` status, we need to add a parameter to enable that.

#### Make Order Service Unit Test Match Code Changes

Now you need to make the unit tests match the code changes you made. Change the **order-service** `OrderServiceTest` class `placeOrder`  test function to send the new status parameter you added to the `OrderService` `placeOrder` function:

```java
    @Test
    public void placeOrder() {
        final Order order = orderService.placeOrder(mockOrderDetails,"PENDING");
```

##### What do these changes do?

Because you added a new parameter to `orderService.placeOrder`, you must add that parameter in the test of that function.

#### Make Order Controller Unit Test Match Code Changes

Change the **order-service** `OrdersControllerTest` class `placeOrder_withHeaders_OK_Response()`  test function to send the new status parameter you added to the `OrderService` `placeOrder` function.

You only need to change this line:

```java
Mockito.when(orderService.placeOrder(Mockito.any())).thenReturn(mockOrder);
```

into this :

```java
 Mockito.when(orderService.placeOrder(Mockito.any(),Mockito.anyString())).thenReturn(mockOrder);
```

##### What do these changes do?

Because you added a new parameter to `orderService.placeOrder`, you must add that parameter in the test of that function. By using `Mockito.anyString()` we make the mock `orderService` return the `mockOrder` if `PENDING` or `UNCONFIRMED`, or even some other string is sent into the `status` parameter.

## Building and Running

Now let's check that the **order-service** really places orders with a different status when **user-service** is slow. 

### Make Sure that All Required Tools are Running

Since in previous chapters you added messaging and database support to Ticket Monster, **user-service** and **order-service** now depend on Kafka, Zookeeper, and Couchbase to be running in order to work. If they are not, or you are not sure, read through the previous steps to see how to check if they are running, and how to start them if they are not.

If **user-service** or **order-service** are running, make sure you stop them before building. Also make sure you have saved all your changes.

### Build the User Service

**Note:** Because the **order-service** build runs an integration test that uses the same port as the production **user-service**, if **user-service** is running when we build **order-service**, the build will fail. You need to first build the two services, and then run them.

1. In the Terminal, change to the **md205/sandbox/user-service** directory.

2. Package the application with: `mvn clean package`

   Make sure that all the unit and integration tests passed, that there were no failures or errors, and that Maven terminated with a `[INFO] BUILD SUCCESS` message

### Build the Order Service

1. In another Terminal, change to the **md205/sandbox/order-service** directory.

2. Package the application with: `mvn clean package`

   Make sure that all the unit and integration tests passed, that there were no failures or errors, and that Maven terminated with a `[INFO] BUILD SUCCESS` message

### Run the User Service

In the terminal where you built it, run the **user-service** with: `java -jar target/user-service-md205-0.1.0.jar`

### Run the Order Service

In the terminal where you built it, run the **order-service** with: `java -jar target/order-service-md205-0.1.0.jar`

### Try to Place an Order

Leave the servers running in their Terminal windows, and open a new Terminal window. In the new Terminal, enter the following command that will be sent to **order-service**:

```
$ curl -i -H "Content-Type: application/json" -H "userID: 0" -d '{"eventName": "Event1", "venue": "Venue1", "eventDate": "2020-05-02T20:00:00", "numberOfTickets": 2}' http://localhost:8080/orders

```

You should see the order placed with the `UNCONIRMED` order status.

```
{"eventName":"Event1","venue":"Venue1","eventDate":"2020-05-02T20:00:00","numberOfTickets":2,"orderDate":"2019-05-17T15:10:08.722625","orderStatus":"UNCONFIRMED","orderId":"3bf04fe3-37f6-400c-88cd-4c22dee01d1c"}
```

The **order-service** tried to create an order for user 0, so it called **user-service** `getUserByID` to see if that is a valid user. But **user-service** is stuck trying to read from the keyboard, so it does not respond. When the service does not respond longer than the Hystrix default timeout, Hystrix returned the fallback `UserServiceFallback.UNCONFIRMED_USER` value, which caused **order-service** to place the order as `UNCONFIRMED`.

This demonstrates how using Hystrix fallback values you can isolate slow services and avoid having them slow down the entire application. Try placing some more orders and see that they have the same status.

**A cool trick to try** is to keep issuing orders, but at the same time press ENTER a few times in the Terminal window where you ran **user-service**. This should release **user-service** from being stuck at `System.in.read()`, and some orders should be completed with a `PENDING` status.

### Try Removing the Delay in User-Service

To see how Hystrix works when the service goes back to normal, you can stop **user-service**, and remove the line that made it wait for keyboard input in the `UserController`class:

```java
	public ResponseEntity<User> getUser(@ApiParam("Id of the user to get") @PathVariable final String id) {

    
//    	try {
//			System.in.read();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}

```

and then build and run user-service again as you did before.

### Restore the Commented Out Tests

As a final step, remove the comments that you added earlier in this step which disabled tests in the `UserControllerTest` and `UserIntegrationTest` classes. Now that you have removed the problematic delay, the tests can be restored and run as before.

```java
	@Test
	public void deleteUserSendsMessage() throws Exception {
...
    @Test
	public void getUserById_Match() throws Exception {
...
	@Test
	public void getUserById_NoMatch() throws Exception {
...
	@Test
	public void createUser() throws Exception {
...
    @Test
	public void updateUser() throws Exception {
...
    @Test
	public void deleteUser() throws Exception {

```

```java
	@Test
	public void getUserById_Match() {
...
    @Test
	public void getUserById_NoMatch() {
...
	@Test
	public void createUser() {
...
	@Test
	public void updateUser() {
...
	@Test
	public void deleteUser() {
```



### Try to Place an Order

In a Terminal, enter the following command that will be sent to **order-service**:

```
$ curl -i -H "Content-Type: application/json" -H "userID: 0" -d '{"eventName": "Event1", "venue": "Venue1", "eventDate": "2020-05-02T20:00:00", "numberOfTickets": 2}' http://localhost:8080/orders

```

Once the **user-service** is finished booting up and is running, you should see the order placed with the `PENDING` order status as usual:

```
{"eventName":"Event1","venue":"Venue1","eventDate":"2020-05-02T20:00:00","numberOfTickets":2,"orderDate":"2019-05-17T15:18:53.5122649","orderStatus":"PENDING","orderId":"2561cec6-8999-40ed-80c3-13d92ea636ac"}
```

Now that **user-service** is back to normal , Hystrix lets the call go through to the service, and it responds with the validated user as before.



Congratulations!  You just added Circuit Breaking with fallbacks to Ticket Monster!

## Summary

In this step you added Circuit Breaking with fallbacks to order-service to improve your applications fault tolerance, reduce latency and isolate slow services.

In the next step you will add testing to the new code and features, and discuss some of the challenges of using Hystrix circuit breaking.

_**Want to learn more?** See the "Dive Deeper" section in the chapter introduction (Jam page) for links to articles and videos about the topics in this chapter._

### Go to Step 2

Ready to go to the Step 2 branch?

1. In the Terminal, make sure you are in the **md205** directory. (Use the `pwd` command to check your current directory. Use the `cd` command to change directories.)
2. To change branches, enter the following command: `git checkout step_2`
3. In STS, right-click the **end** project and select **Refresh** to make sure you're viewing the end state for Step 2.
4. Refresh Firefox to view the README for Step 2. (You may need to scroll up after refreshing.)

