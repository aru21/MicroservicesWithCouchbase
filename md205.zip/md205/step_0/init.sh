echo 'Creating sandbox directory...'
mkdir sandbox
echo 'Copying code into sandbox...'
cp -r init/* sandbox/
echo 'Initialization complete!'
