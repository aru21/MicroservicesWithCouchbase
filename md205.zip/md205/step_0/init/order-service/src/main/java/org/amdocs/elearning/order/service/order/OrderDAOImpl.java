package org.amdocs.elearning.order.service.order;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

@Service
public class OrderDAOImpl implements OrderDAO {

	private OrderRepository orderRepository;

	@Autowired
	public OrderDAOImpl(OrderRepository orderRepository) {
		this.orderRepository = orderRepository;
	}

	public List<Order> findByEventNameLike(String eventName, int page) {
		return orderRepository.findByEventNameLikeOrderByEventName(eventName, PageRequest.of(page, 20)).getContent();
	}

    @Override
    public Optional<Order> findById(UUID orderID) {
        return orderRepository.findById(orderID);
    }

    @Override
    public Order save(@Valid Order order) {
        return orderRepository.save(order);
    }

    @Override
    public Long countOrders(String venue) {
        return orderRepository.countOrders(venue);
    }

    @Override
	public void deleteOrder(UUID orderID)
    {
    	orderRepository.deleteById(orderID);
    }
    
    @Override 
    public Iterable<Order> getOrders()
    {
    	return orderRepository.findAll();

    }
}