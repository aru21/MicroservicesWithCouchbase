package org.amdocs.elearning.order.service.order;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;

import com.couchbase.client.java.repository.annotation.Field;

public class Order{
	
    @NotNull
    @Field
    protected String eventName;
    @NotNull
    @Field
    protected String venue;
    @NotNull
    @Field
    protected LocalDateTime eventDate;
    @NotNull
    @Field
    protected int numberOfTickets;
    
    @Id
    private UUID id;
    @Field
    private LocalDateTime orderDate;
    @Field
    private String orderStatus;

    public Order() {

    }

    public Order(UUID id, LocalDateTime date, String status, OrderDetails order) {
        this.id = id;
        this.orderDate = date;
        this.orderStatus = status;
        this.eventName = order.getEventName();
        this.venue = order.getVenue();
        this.eventDate = order.getEventDate();
        this.numberOfTickets = order.getNumberOfTickets();
    }

    public Order(UUID id, LocalDateTime date, String status, String eventName, LocalDateTime eventDate, String venue, int numberOfTickets) {
        this.id = id;
        this.orderDate = date;
        this.orderStatus = status;
        this.eventName = eventName;
        this.venue = venue;
        this.eventDate = eventDate;
        this.numberOfTickets = numberOfTickets;
    }
    
    public String getEventName() {
        return eventName;
    }

    public String getVenue() {
        return venue;
    }

    public LocalDateTime getEventDate() {
        return eventDate;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }
    

    public UUID getOrderId() {
        return id;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventDate == null) ? 0 : eventDate.hashCode());
		result = prime * result + ((eventName == null) ? 0 : eventName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + numberOfTickets;
		result = prime * result + ((orderDate == null) ? 0 : orderDate.hashCode());
		result = prime * result + ((orderStatus == null) ? 0 : orderStatus.hashCode());
		result = prime * result + ((venue == null) ? 0 : venue.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (eventDate == null) {
			if (other.eventDate != null)
				return false;
		} else if (!eventDate.equals(other.eventDate))
			return false;
		if (eventName == null) {
			if (other.eventName != null)
				return false;
		} else if (!eventName.equals(other.eventName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (numberOfTickets != other.numberOfTickets)
			return false;
		if (orderDate == null) {
			if (other.orderDate != null)
				return false;
		} else if (!orderDate.equals(other.orderDate))
			return false;
		if (orderStatus == null) {
			if (other.orderStatus != null)
				return false;
		} else if (!orderStatus.equals(other.orderStatus))
			return false;
		if (venue == null) {
			if (other.venue != null)
				return false;
		} else if (!venue.equals(other.venue))
			return false;
		return true;
	}
    
    
}