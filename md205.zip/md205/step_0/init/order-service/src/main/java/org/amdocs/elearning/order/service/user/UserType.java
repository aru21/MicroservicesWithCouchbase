package org.amdocs.elearning.order.service.user;

public enum UserType {
    PATRON, VENUE_OWNER
}