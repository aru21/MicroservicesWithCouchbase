package org.amdocs.elearning.order.service.order;

import java.util.UUID;

public interface OrderIDGenerator {
  public abstract UUID getNextID();
}