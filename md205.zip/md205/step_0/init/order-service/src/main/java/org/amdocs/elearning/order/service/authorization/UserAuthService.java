package org.amdocs.elearning.order.service.authorization;

import java.util.Optional;

import org.amdocs.elearning.order.service.user.User;
import org.amdocs.elearning.order.service.user.UserType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.HttpStatusCodeException;


public class UserAuthService {
	
    @Autowired
	public UserAuthService(UserServiceClient userServiceClient)
	{
		this.userServiceClient = userServiceClient;
	}
    private UserServiceClient userServiceClient;
    
    public Optional<User> validateUserByID(String userID) {
        try{
        	User user = userServiceClient.getUserByID(userID);

            if(user.getUserType().equals(UserType.PATRON)) {
                return Optional.of(user);
            } else {
                return Optional.empty();
            }

        } catch(HttpStatusCodeException e) {
            return Optional.empty();
        }

    }

}