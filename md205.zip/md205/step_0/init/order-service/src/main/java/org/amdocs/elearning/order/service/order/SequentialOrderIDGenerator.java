package org.amdocs.elearning.order.service.order;

import java.util.UUID;

import org.springframework.stereotype.Service;

@Service("sequentialIDGenerator")
public class SequentialOrderIDGenerator implements OrderIDGenerator {

	int counter = 0;
	@Override
	public UUID getNextID() {
		return UUID.fromString(String.format("%08d-0000-0000-0000-000000000000", ++counter));
	}

}
