package org.amdocs.elearning.order.service.order;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Service;
import org.springframework.cloud.stream.messaging.Sink;

@Service
public class MessageListenerService {

	private Logger log = LoggerFactory.getLogger(MessageListenerService.class);
	
	public void setLogger( Logger log )
	{
		this.log = log;
	}

	private Pattern p = Pattern.compile("deleted user (\\d+)");

	public MessageListenerService() {
		log.info("************   Starting Order Service Message Listener ******** ");
	}

	@StreamListener(Sink.INPUT)
	public void consume(String message) {
		log.info("Order Service Received Message : " + message);
		Matcher matcher = p.matcher(message);
		if (matcher.matches()) {
			int userID = Integer.parseInt(matcher.group(1));
			log.info("All orders of user #" + userID + " should be deleted");
		}
	}
}
