package org.amdocs.elearning.order.service;

import org.amdocs.elearning.order.service.authorization.UserAuthService;
import org.amdocs.elearning.order.service.authorization.UserServiceClient;
import org.amdocs.elearning.order.service.order.OrderDAO;
import org.amdocs.elearning.order.service.order.OrderIDGenerator;
import org.amdocs.elearning.order.service.order.OrderService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("Production")
@RibbonClient(name = "user-service", configuration = RibbonConfig.class)  
public class ApplicationConfig {
   
    @Bean
    public OrderService getOrderService(OrderDAO orderDAO, @Qualifier("randomIDGenerator") OrderIDGenerator orderIDGenerator) {
        return new OrderService(orderDAO,orderIDGenerator);
    }

    @Bean
    public UserAuthService getUserAuthService(UserServiceClient userServiceClient) {
        UserAuthService userAuthService = new UserAuthService(userServiceClient);
		return userAuthService;
    }

}