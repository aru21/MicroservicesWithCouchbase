package org.amdocs.elearning.order.service.order;

import java.util.UUID;

import org.springframework.stereotype.Component;

@Component("randomIDGenerator")
public class RandomOrderIDGenerator implements OrderIDGenerator {

	@Override
	public UUID getNextID() {
		return UUID.randomUUID();
	}
}
