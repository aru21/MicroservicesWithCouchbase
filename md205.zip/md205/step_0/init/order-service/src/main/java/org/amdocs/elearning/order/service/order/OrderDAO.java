package org.amdocs.elearning.order.service.order;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.validation.Valid;

public interface OrderDAO {

    Order save(@Valid Order order);

    Optional<Order> findById(UUID orderId);

    List<Order> findByEventNameLike(String eventName, int page);

    Long countOrders(String venue);
    
    void deleteOrder(UUID orderID);

	Iterable<Order> getOrders();

}
