package org.amdocs.elearning.order.service.order;

import java.util.List;
import java.util.UUID;

import org.springframework.data.couchbase.core.query.N1qlPrimaryIndexed;
import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.CouchbasePagingAndSortingRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@N1qlPrimaryIndexed
@ViewIndexed(designDoc = "order")
public interface OrderRepository extends CouchbasePagingAndSortingRepository<Order, UUID> {

    Page<Order> findByEventNameLikeOrderByEventName(String eventName, Pageable pageable);

    @Query("SELECT COUNT(*) AS count FROM #{#n1ql.bucket} WHERE #{#n1ql.filter} and venue = $1")
    Long countOrders(String venue);
    
    @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter}")
    List<Order> findAll2();
    
}
