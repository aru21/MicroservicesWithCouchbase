package org.amdocs.elearning.order.service.order;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderDAOIntegrationTest {

    public static final UUID ORDER_ID_1 = UUID.fromString("00000001-0000-0000-0000-000000000000");
    public static final UUID ORDER_ID_2 = UUID.fromString("00000002-0000-0000-0000-000000000000");
    public static final UUID ORDER_ID_3 = UUID.fromString("00000003-0000-0000-0000-000000000000");
	public static final LocalDateTime CURRENT_DATE = LocalDateTime.now();
	public static final LocalDateTime EVENT_DATE = LocalDateTime.now();

    @Autowired
    private OrderDAO orderDAO;

	@Autowired
	protected OrderRepository orderRepository;

	@Before
	public void deleteAll(){
		orderRepository.deleteAll();
	}

	@After
	public void deleteTestDataAfterTest(){
		orderRepository.deleteAll();
	}
	
    @AfterClass
    public static void waitALittle()
    {
    	try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @Test
    public void testSave() {
		Order order = new Order(ORDER_ID_1,CURRENT_DATE,"PENDING","event1",EVENT_DATE,"venue1",1);
        orderDAO.save(order);

        Optional<org.amdocs.elearning.order.service.order.Order> savedOrder = orderDAO.findById(ORDER_ID_1);
        assertThat(savedOrder.get(), equalTo(order));
    }

    @Test(expected = ConstraintViolationException.class)
    public void testSaveWithMissingNameField() {
		Order order = new Order(ORDER_ID_1,CURRENT_DATE,"PENDING",null,EVENT_DATE,"venue1",1);
        orderDAO.save(order);
    }

    @Test
    public void testFindByEventNameLike() {
		String event1Name = "event1";
		Order order = new Order(ORDER_ID_1,CURRENT_DATE,"PENDING",event1Name,EVENT_DATE,"venue1",1);
        orderDAO.save(order);

		String event2Name = "event2";
		Order order2 = new Order(ORDER_ID_2,CURRENT_DATE,"PENDING",event2Name,EVENT_DATE,"venue1",1);
        orderDAO.save(order2);

		Order order3 = new Order(ORDER_ID_3,CURRENT_DATE,"PENDING","happening",EVENT_DATE,"venue1",1);
        orderDAO.save(order3);

        List<Order> orders = orderDAO.findByEventNameLike("event%", 0);

        assertThat(orders, hasSize(2));
        List<String> orderEventNames = orders.stream().map(e->e.getEventName()).collect(Collectors.toList());
        assertThat(orderEventNames, contains(event1Name,event2Name));
    }




    @Test
    public void testCount() {
		String event1Name = "event1";
		Order order = new Order(ORDER_ID_1,CURRENT_DATE,"PENDING",event1Name,EVENT_DATE,"venue1",1);
        orderDAO.save(order);

		String event2Name = "event2";
		Order order2 = new Order(ORDER_ID_2,CURRENT_DATE,"PENDING",event2Name,EVENT_DATE,"venue1",1);
        orderDAO.save(order2);

		Order order3 = new Order(ORDER_ID_3,CURRENT_DATE,"PENDING","happening",EVENT_DATE,"venue1",1);
        orderDAO.save(order3);

        Long count = orderDAO.countOrders("venue1");

        assertEquals(3,(long) count);
    }
    
    @Test
    public void deleteOrder()
    {
		Order order = new Order(ORDER_ID_1,CURRENT_DATE,"PENDING","event1",EVENT_DATE,"venue1",1);
        orderDAO.save(order);
        orderDAO.deleteOrder(ORDER_ID_1);

        Optional<org.amdocs.elearning.order.service.order.Order> savedOrder = orderDAO.findById(ORDER_ID_1);
        
        Assert.assertFalse( savedOrder.isPresent() );
    	
    }
   
    @Test
    public void getOrders()
    {
		Order order = new Order(ORDER_ID_1,CURRENT_DATE,"PENDING","someEvent",EVENT_DATE,"venue1",1);
        orderDAO.save(order);

		Order order2 = new Order(ORDER_ID_2,CURRENT_DATE,"PENDING","someEvent",EVENT_DATE,"venue1",1);
        orderDAO.save(order2);

		Order order3 = new Order(ORDER_ID_3,CURRENT_DATE,"PENDING","someEvent",EVENT_DATE,"venue1",1);
        orderDAO.save(order3);

        Iterable<Order> orders = orderDAO.getOrders();
    	List<Order> ordersList = new ArrayList<Order>();
		orders.forEach(ordersList::add);

        Assert.assertTrue(ordersList.containsAll(Arrays.asList(order,order2,order3)));
    	
    }
}
