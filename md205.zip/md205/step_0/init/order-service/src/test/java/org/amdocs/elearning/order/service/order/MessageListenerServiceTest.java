package org.amdocs.elearning.order.service.order;


import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;

public class MessageListenerServiceTest {

 Logger mockLogger = Mockito.mock(Logger.class);
 MessageListenerService listenerService = new MessageListenerService();
 
 @Before
 public void testSetup()
 {
	listenerService.setLogger(mockLogger); 
 }
 @Test
 public void testRegExpressionMatchDeleteOrders()
 {
   listenerService.consume("deleted user 3");
   Mockito.verify(mockLogger).info("Order Service Received Message : deleted user 3");
   Mockito.verify(mockLogger).info("All orders of user #3 should be deleted");
 }
 
 @Test
 public void testRegExpressionNoMatchNoDeleteOrders()
 {
   listenerService.consume("some other message");
   Mockito.verify(mockLogger).info("Order Service Received Message : some other message");
   Mockito.verifyNoMoreInteractions(mockLogger);
 }
}
