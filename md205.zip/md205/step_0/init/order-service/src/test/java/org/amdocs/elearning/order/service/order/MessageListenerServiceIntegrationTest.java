package org.amdocs.elearning.order.service.order;

import org.amdocs.elearning.order.service.Application;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class MessageListenerServiceIntegrationTest {

	@Autowired
	private Sink channels;

	@SpyBean
	private MessageListenerService listenerService;

	Logger mockLogger = Mockito.mock(Logger.class);

	@Before
	public void testSetup()
	{
		listenerService.setLogger(mockLogger);		
	}
	
	@Test
	public void testDeleteMessageDeleteOrders() {
		this.channels.input().send(new GenericMessage<>("deleted user 3"));
		   Mockito.verify(mockLogger).info("Order Service Received Message : deleted user 3");
		   Mockito.verify(mockLogger).info("All orders of user #3 should be deleted");
	}
	
	 @Test
	 public void testWrongMessagesNoDeleteOrders()
	 {
	   this.channels.input().send(new GenericMessage<>("some other message"));
	   Mockito.verify(mockLogger).info("Order Service Received Message : some other message");
	   Mockito.verifyNoMoreInteractions(mockLogger);
	 }

}