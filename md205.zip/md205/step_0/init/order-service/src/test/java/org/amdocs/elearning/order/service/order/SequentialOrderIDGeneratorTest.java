package org.amdocs.elearning.order.service.order;

import org.junit.Assert;
import org.junit.Test;

public class SequentialOrderIDGeneratorTest {

	@Test
	public void testIDSequence() {
		SequentialOrderIDGenerator sequentialOrderIDGenerator = new SequentialOrderIDGenerator();
        Assert.assertEquals("00000001-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000002-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000003-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000004-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000005-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000006-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000007-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000008-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000009-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());
        Assert.assertEquals("00000010-0000-0000-0000-000000000000",sequentialOrderIDGenerator.getNextID().toString());

	}

}
