package org.amdocs.elearning.user.service.user;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

@RepositoryRestResource(collectionResourceRel = "usersDataREST", path = "usersDataREST")
public interface UserRepository extends CrudRepository<User, String> {
	List<User> findByIdIgnoreCase(String id);
	List<User> findByFirstName(@Param("name") String name);
	@Override
	@RestResource(exported = false)
	void deleteById(String id);
}
