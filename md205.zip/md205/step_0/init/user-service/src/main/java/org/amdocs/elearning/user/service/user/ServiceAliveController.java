package org.amdocs.elearning.user.service.user;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceAliveController {

	  @RequestMapping(value = "/")
	  public String home() {
	    return "Service Is Alive";
	  }
}
