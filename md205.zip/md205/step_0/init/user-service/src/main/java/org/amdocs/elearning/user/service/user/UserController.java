package org.amdocs.elearning.user.service.user;

import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/users")   
@Api(tags = { "User Management" })
public class UserController {

    private static Logger log = LoggerFactory.getLogger(UserController.class);

	private final UserService userService;
	private final Environment environment;

	@Autowired
	public UserController(final UserService userService, final Environment environment) {
		this.userService = userService;
		this.environment = environment;
	}

    @ApiOperation(value = "Get a user from the registered users",response = User.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the requested user"),
            @ApiResponse(code = 404, message = "Could not find requested user")
    })
	@RequestMapping(path = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<User> getUser(@ApiParam("Id of the user to get") @PathVariable final String id) {

   	    String port = environment.getProperty("local.server.port");
		log.info("Accessing user-service/users/getUser on port " + port );

		final Optional<User> userOptional = this.userService.getUserById(id);

		if (userOptional.isPresent()) {
			return new ResponseEntity<User>(userOptional.get(), HttpStatus.OK);
		}

		return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(path = "/{id}", method = RequestMethod.PUT)
	public ResponseEntity<User> updateUser(@PathVariable final String id, @RequestBody @Valid final UserDetails user) {

		final User updatedUser = this.userService.updateUser(id, user);
		return new ResponseEntity<User>(updatedUser, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<User> createUser(@RequestBody @Valid final UserDetails user) {

		final User createdUser = this.userService.createUser(user);
		return new ResponseEntity<User>(createdUser, HttpStatus.CREATED);
	}

	@RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable final String id) {

		final Optional<User> user = this.userService.getUserById(id);
		if (!user.isPresent()) {
			return new ResponseEntity<HttpStatus>(HttpStatus.NOT_FOUND);
		} else {
			this.userService.deleteUser(user.get().getId());
			return new ResponseEntity<HttpStatus>(HttpStatus.NO_CONTENT);
		}
	}

}