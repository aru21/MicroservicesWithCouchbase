package org.amdocs.elearning.user.service.user;

import java.util.Optional;

import org.springframework.cloud.stream.messaging.Source;
import org.springframework.messaging.support.MessageBuilder;

public class UserService {

	private UserRepository userRepository;
	private Source messageSource;
	
	public UserService(UserRepository userRepository, Source messageSource) {
		this.userRepository = userRepository;
		this.messageSource = messageSource;
	}

	public Optional<User> getUserById(final String id) {
		return userRepository.findByIdIgnoreCase(id).stream().findFirst();
	}

	public User createUser(final UserDetails userDetails) {
		long newUserId = userRepository.count();
		final User newUser = new User(String.valueOf(newUserId), userDetails);
		userRepository.save(newUser);
		return newUser;

	}

	public User updateUser(final String userId, final UserDetails user) {
		final User newUser = new User(String.valueOf(userId), user);
		userRepository.save(newUser);
		return newUser;
	}

	public void deleteUser(final String userId) {
		messageSource.output().send(MessageBuilder.withPayload("deleted user "+userId).build());
		userRepository.deleteById(userId);
	}

}
