package org.amdocs.elearning.user.service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;

import org.amdocs.elearning.user.service.user.User;
import org.amdocs.elearning.user.service.user.UserDetails;
import org.amdocs.elearning.user.service.user.UserRepository;
import org.amdocs.elearning.user.service.user.UserService;
import org.amdocs.elearning.user.service.user.UserType;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

public class UserServiceTest {

	UserRepository mockRepository = Mockito.mock(UserRepository.class);
	Source mockMessageSource = Mockito.mock(Source.class);
	final UserService userService = new UserService(mockRepository,mockMessageSource);
	
	@Test
	public void getUser_Match() {
		User mockUser = new User();
		Mockito.when(mockRepository.findByIdIgnoreCase("0")).thenReturn(Arrays.asList(mockUser));
		final Optional<User> userOptional = userService.getUserById("0");
		Assert.assertEquals(mockUser, userOptional.get());
	}

	@Test
	public void getUser_NoMatch() {
		final Optional<User> user = userService.getUserById("not a real id");
		Assert.assertEquals(false, user.isPresent());
	}

	@Test
	public void createUser() {
		final UserDetails newUser = new UserDetails("new first", "new last", "M", UserType.PATRON, LocalDate.now());
		
		// call the service
		final UserDetails userDetails = new UserDetails("new first", "new last", "M", UserType.PATRON, LocalDate.now());
		final User returnedUser = userService.createUser(newUser);

		//Check that the returned user object has the right details
		Assert.assertEquals(userDetails.getFirstName(),returnedUser.getFirstName());
		Assert.assertEquals("0",returnedUser.getId());
		
		// capture the user that was saved
		ArgumentCaptor<User> savedUserCaptor = ArgumentCaptor.forClass(User.class);
		Mockito.verify(mockRepository).save(savedUserCaptor.capture());
		User savedUser = savedUserCaptor.getValue();
		
		//Check that the saved user has the right details
		Assert.assertEquals(savedUser.getFirstName(),returnedUser.getFirstName());
		Assert.assertEquals("0",returnedUser.getId());

	}

	@Test
	public void updateUser() {
		
		// call the service
		final UserDetails userDetails = new UserDetails("new first", "new last", "M", UserType.PATRON, LocalDate.now());
		final User returnedUser = userService.updateUser("0", userDetails);

		//Check that the returned user object has the right details
		Assert.assertEquals(userDetails.getFirstName(),returnedUser.getFirstName());
		
		// capture the user that was saved
		ArgumentCaptor<User> savedUserCaptor = ArgumentCaptor.forClass(User.class);
		Mockito.verify(mockRepository).save(savedUserCaptor.capture());
		User savedUser = savedUserCaptor.getValue();
		
		//Check that the saved user has the right details
		Assert.assertEquals(savedUser.getFirstName(),returnedUser.getFirstName());


	}

	@Test
	public void deleteUser() {
		MessageChannel mockMessageChannel = Mockito.mock(MessageChannel.class);
		Mockito.when(mockMessageSource.output()).thenReturn(mockMessageChannel);	
		userService.deleteUser("0");
		final Optional<User> retrievedUser = userService.getUserById("0");
		Assert.assertFalse(retrievedUser.isPresent());
		Mockito.verify(mockRepository).deleteById("0");
		Mockito.verify(mockMessageChannel).send(Mockito.any(Message.class));
	}

}
