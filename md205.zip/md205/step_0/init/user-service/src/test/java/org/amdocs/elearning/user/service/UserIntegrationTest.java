package org.amdocs.elearning.user.service;



import static org.hamcrest.CoreMatchers.is;

import java.time.LocalDate;
import java.util.concurrent.BlockingQueue;

import org.amdocs.elearning.user.service.user.User;
import org.amdocs.elearning.user.service.user.UserDetails;
import org.amdocs.elearning.user.service.user.UserType;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.cloud.stream.test.binder.MessageCollector;
import org.springframework.cloud.stream.test.matcher.MessageQueueMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserIntegrationTest {

	@LocalServerPort
	private int port;

	@Autowired
	private TestRestTemplate restTemplate;

	@Autowired
	private Source channels;

	@Autowired
	private MessageCollector collector;
	
	@Test
	public void deleteUserSendsMessage() throws Exception {
		this.restTemplate.delete("http://localhost:" + port + "/users/0");
		BlockingQueue<Message<?>> messages = collector.forChannel(channels.output());

	    Assert.assertThat(messages, MessageQueueMatcher.receivesPayloadThat(is("deleted user 0")));

	}
	
	@Test
	public void getUserById_Match() throws Exception {
		final ResponseEntity<User> responseEntity = this.restTemplate
				.getForEntity("http://localhost:" + port + "/users/0", User.class);
		Assert.assertEquals(200, responseEntity.getStatusCodeValue());
		Assert.assertNotNull(responseEntity.getBody());
	}

	@Test
	public void getUserById_NoMatch() throws Exception {
		final ResponseEntity<User> responseEntity = this.restTemplate
				.getForEntity("http://localhost:" + port + "/users/abc", User.class);
		Assert.assertEquals(404, responseEntity.getStatusCodeValue());
		Assert.assertNull(responseEntity.getBody());
	}

	@Test
	public void createUser() throws Exception {

		final UserDetails user = new UserDetails("firstName", "lastName", "M", UserType.PATRON, LocalDate.now());
		final ResponseEntity<User> responseEntity = this.restTemplate
				.postForEntity("http://localhost:" + port + "/users", user, User.class);

		Assert.assertEquals(201, responseEntity.getStatusCodeValue());
		Assert.assertNotNull(responseEntity.getBody());
	}

	@Test
	public void updateUser() throws Exception {

		final User user = new User(null, "firstName", "lastName", "M", UserType.PATRON, LocalDate.now());

		this.restTemplate.put("http://localhost:" + port + "/users/00000000-0000-0000-0000-000000000000", user,
				User.class);

		final ResponseEntity<User> responseEntity = this.restTemplate
				.getForEntity("http://localhost:" + port + "/users/00000000-0000-0000-0000-000000000000", User.class);
		Assert.assertEquals(200, responseEntity.getStatusCodeValue());
		Assert.assertEquals("firstName", responseEntity.getBody().getFirstName());
		Assert.assertEquals("lastName", responseEntity.getBody().getLastName());
	}

	@Test
	public void deleteUser() throws Exception {
		this.restTemplate.delete("http://localhost:" + port + "/users/0");
		final ResponseEntity<User> responseEntity = this.restTemplate
				.getForEntity("http://localhost:" + port + "/users/0", User.class);
		Assert.assertEquals(404, responseEntity.getStatusCodeValue());
		Assert.assertNull(responseEntity.getBody());

	}

}
