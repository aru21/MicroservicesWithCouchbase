# MD205 - Circuit Breaking and Fault Tolerance

Hystrix is a latency and fault tolerance library designed to help complex distributed systems stop a slow or remote service from causing global slow downs and cascading failures. This chapter explores how to do this using the Circuit Breaking pattern and the Hystrix library.

---

## How This Chapter Works

This chapter is divided into steps. Each step gives you the following:

- A **README** document that guides you through a learning exercise
- A **sandbox** project (directory) where you will write your code
- An **end** project (directory) that shows you what your code should look like when you're done with the step

### Using Git Commands

When you are done with a step, you will need to use a Git command to move to the next step. Git is a tool for managing source code. All of the code for this chapter lives in a one place, called a _repository_. The repository is organized into different but parallel _branches_, one for each step.

Don't worry if you're not familiar with Git repositories or branches. All you have to do is enter the provided commands. Just be aware you are using Git when you do!

------

## Set Up Your Project

Before you begin coding, you need to take a few steps to set up your project inside your virtual development environment.

First, initialize the project to create your working directories:

1. Open the **Terminal** using the shortcut on the virtual desktop.
2. To change to the root course directory, enter the following command: `cd ~/Desktop/courses/md205`
3. To initialize the project, enter the following command: `sh init.sh`

**IMPORTANT:** All instructions are relative to the **~/Desktop/courses/md205** directory. If you get lost, you can always find your way from here. 

Next, import the **sandbox** projects into STS.

1. Open **Spring Tool Suite (STS)** using the shortcut on the virtual desktop.
2. In STS, select **File > Import**.
3. In the list, select **Maven > Existing Maven Projects** and click **Next**.
4. Click **Browse**, select the **md205/sandbox** directory, and click **OK**. (Make sure the check box is selected for both the **user-service** and the **order-service** projects.)
5. Click **Finish**.

Finally, import the **end** projects into STS. Repeat the steps above, but this time select the **md205/end** directory. You should now see a total of four projects in STS, similar to the screenshot below.

**NOTE:** Feel free to delete any projects from previous chapters. In STS, right-click the root of the project and select **Delete**.

![STS Project Explorer](images/sts-projects.png "STS Project Explorer")

### What Just Happened?

By going through the process above, you divided your work environment into three phases, each with its own subdirectory. In the Terminal, list the contents of the **md205** directory using the `ls` command. You will see the following subdirectories:

- **init** - Contains the initial code for the exercise
- **sandbox** - Contains your workspace
- **end** - Contains an example of the finished code for the step

You then imported the **sandbox** and **end** subdirectories into STS as projects. You will add your own code in the **sandbox** projects. As you work, feel free to look at the contents of the **end** projects to see what your finished code should look like.

**NOTE:** Unlike in previous chapters, the **sandbox** subdirectory contains two projects, one for **user-service** and one for **order-service**. The **end** subdirectory also contains two projects.

### Moving Between Steps

Now that your workspace is set up, you're ready to move on to Step 1. As mentioned above, each step is organized under its own branch. To go to a step, simply check out the branch for that step. This replaces the files in the **md205** directory with the files for the new step.

**IMPORTANT:** When you go to the next step, this README you're reading right now will be replaced with the README for the new step. The files in the **end** projects in STS will also be replaced with the end state for the new step. However, your files in the **sandbox** projects won't be changed, so you can keep building on them. in the **sandbox** project won't be changed, so you can keep building on them.

### Go to Step 1

Ready to go to the Step 1 branch?

1. In the Terminal, make sure you are in the **md205** directory. (Use the `pwd` command to check your current directory. Use the `cd` command to change directories.)
2. To change branches, enter the following command: `git checkout step_1`
3. In STS, right-click either **end** project and select **Refresh** to make sure you're viewing the end state for Step 1.
4. Refresh Firefox to view the README for Step 1. (You may need to scroll up after refreshing.)