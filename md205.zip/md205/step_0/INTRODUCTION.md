# MD205 - Circuit Breaking and Fault Tolerance

This chapter will explore the important topic of fault tolerance in Microservices, and how to achieve it using a pattern called Circuit Breaking. You will implement Circuit Breaking using a library called Hystrix, originally developed by Netflix, and now part of Spring Cloud. 

During this chapter you will:

* Implement the circuit breaker pattern using the Spring Cloud Hystrix library
* Discover the difference between fail fast and using fallback methods.
* Write tests to check your use of the Hystrix library
* Use the Spring Cloud Hystrix Dashboard to discover the state of your services
* 
  Learn about the benefits and challenges of Circuit Breaking and Fault Tolerance.
  

---

## Prerequisites

Before you begin this chapter, you should already have:

* Completed the _[Fundamentals of Microservice Development](https://jam4.sapjam.com/groups/tn6EdYsY8kp1HE6umievq9/overview_page/y01kjzfAYiWA372lAefnJr)_ course

  _OR_

* Some experience working with Spring Boot, Spring annotations and Dependency Injection

---

## Recap of Spring Cloud

Spring Cloud is a Java framework for simplifying cloud based Microservices styled applications by providing commonly needed infrastructure.

According to the official Spring Cloud Documentation, 

> Spring Cloud provides tools for developers to quickly build some of the 
> common patterns in distributed systems (e.g. configuration management, 
> service discovery, circuit breakers, intelligent routing, micro-proxy...

## Recap of Cloud Patterns

*Cloud*-*based* applications are built with services or resources made available to users on demand via the Internet from remote servers, and can be scaled to provide more resources as demand grows. *Microservices* applications are structured as a collection of distributed, loosely coupled fine-grained services, and are often cloud-based.

Cloud-based applications require some common services and infrastructure. You can group the solutions for these problems into *patterns* such as **Discovery**, **Circuit Breaking**, **Load Balancing**, and others. These patterns describe common problems that most cloud based or Microservices styled programs share, and the common architecture and infrastructure used to solve them.  Spring Cloud provides ready made components for these pieces of software, so that you don't have to implement this complex infrastructure yourself.

---

## Microservices and Fault Tolerance 

A *fault* is a failure within a component of a system. *Fault truculence* is the ability of a system to continue operating properly following failure of some of its components. 

Fault tolerance is extremely important and challenging in Microservices applications: 

* Since the system made of many distributed services, restarting it in the event of a failure can be very difficult. 

* Microservices applications inherently have a large number of customers, and so a catastrophic failure could affect a very large client base. 

* Microservices applications are networked, adding slow or failed network connections to the list of things that can go wrong with software.

  

## Cascading Failures and Latency 

Cloud *service latency* is the delay between a client request and the provider's response. In Microservices, high latency can be just as problematic as a failure.

A *cascading failure* is a failure that grows over time , also known as a *snowball effect*, or *domino effect*. It can occur when a portion of an overall system fails, increasing the probability that other portions of the system fail. 

If a service, for example a logging service, takes a long time to respond then all the services that call it can also take a long time to respond, and so can all the services that call them, bringing the system to a crawl.

## The Circuit Breaker Pattern

One solution to cascading failures in Microservices is the Circuit Breaker pattern. It borrows the idea from  electrical circuit breakers.  After a predefined number of failures the circuit breaker opens, and for the duration of a timeout period all calls to the slow or faulty service will fail immediately, or return a predefined *fallback* response without actually calling the remote service.

After the timeout expires the circuit breaker allows test requests to pass through.If those requests succeed the circuit breaker resumes normal operation. 

Here is an excellent short video explaining the Circuit Breaker Pattern

https://www.youtube.com/watch?v=ADHcBxEXvFA

## Hystrix

Hystrix is a fault tolerance and latency reduction library for services, written by Netflix, and now part of Spring Cloud. Here is a quote from their official page:

> Hystrix is a latency and fault tolerance library designed to isolate points of access to remote systems, services and 3rd party libraries, stop cascading failure and enable resilience in complex distributed 
> systems where failure is inevitable.

Most Spring Cloud developers use Hystrix for its implementation of the Circuit Breaker design pattern. It can stop cascading failures with Fallbacks and graceful degradation. In addition Hystrix also features realtime service monitoring to let you watch which services are failing, and concurrency improvements like concurrency aware request caching and automated batching through request collapsing.

Here is a quick video overview of Hystrix:

https://www.youtube.com/watch?v=P1iF8ltmlXE

## Hands-on Time!

Now that you're familiar with Spring annotations and Spring Cloud, it's time to get some experience with it while working in a sample codebase. For the rest of this chapter, you will be doing hands-on exercises inside a virtual development environment.

1. On your computer, launch **VNC Viewer**.
2. Open a VNC connection using the IP address and password that was provided to you. Wait for the virtual desktop to appear.
3. On the virtual desktop, open the **courses** folder, and then open the **md205** folder.
4. Double-click the **README** file to view it in Firefox.

To continue, follow the instructions in the README.

---

## Dive Deeper

Want to learn more? Use the resources below to explore the concepts and tools you encountered in this chapter.

### Microservices with Spring Cloud

- **[Building Microservices With Spring Cloud](https://www.youtube.com/watch?v=ZyK5QrKCbwM)** -Video explaining Spring Cloud from the makers of Spring 

### Circuit Breaker Pattern

- **[The Circuit Breaker Pattern](https://microservices.io/patterns/reliability/circuit-breaker.html)** -Reference page for the pattern from the maker of CloudFoundry

### Hystrix

- **[Hystrix Readme](https://github.com/Netflix/Hystrix/blob/master/README.md)** -Front documentation page of the Hystrix Project
- **[Hystrix How To Use](https://github.com/Netflix/Hystrix/wiki/How-To-Use)** - Simple code examples of how to use Hystrix Commands
- **[Hystrix How It Works](https://github.com/Netflix/Hystrix/wiki/How-it-Works)** - Technological explanation of how  Hystrix actually works

