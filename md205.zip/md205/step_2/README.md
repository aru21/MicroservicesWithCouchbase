# MD205 - Step 2: Testing Hystrix Applications  

Hi there, glad to see you are still with us! You have reached the last step of the advanced Microservices course! 

In the previous step you implemented circuit breaking and fallbacks for **order-service** using Hystrix, and you changed **order-service** so that it could place orders with a special temporary status even when the **user-service** is too slow to use.

In this step you will see how to ensure the correctness of your circuit breaking and fallback implementation by adding integration tests that will simulate a slow or unresponsive service.

_**Need to go back to the previous step?** In the Terminal, enter `git checkout step_1` and then refresh your browser._

---

## Hystrix Challenges and The Importance Of Testing

Using Hystrix in a project can add great benefits such as isolating a slow service and preventing it from slowing down the entire application. But this can only happen if the application uses Hystrix correctly. 

#### Negative Tests

Developers often concentrate on testing the normal program flow, where everything works as it should, and forget to introduce error conditions ( such as a slow service ) to see that the fault handling code works as well. 

Tests that check the normal flow are called *positive tests* or *functional tests*. Tests that check that the error handling code works correctly are called *negative tests*.

So what could go wrong with using Hystrix?

#### Hystrix Challenges

The default thresholds may not be appropriate for a specific circuit. As you may recall Hystrix has some defaults for its algorithm of when to open a circuit. For example it normally requires at least 20 calls to a service before tripping the circuit breaker, no matter how many failures there are. If we have a service that does not get many calls, but still requires circuit breaking, we will have to change the defaults. To tune Hystrix correctly thresholds should be set based on observing a production environment. However, production data may not be available to developers.

If we set the minimal values too low, a circuit might open too soon, for example after only one slow call. Even if the service becomes fast and responsive immediately after, Hystrix will not forward calls to the service until the sleep window time expires.

## Simulating A Slow Service

### Wire Mock

As you may recall WireMock is a testing tool used in Ticket Monster to create a fake **user-service**, for the integration tests of **order-service**. Instead of having **order-service** require a real **user-service** instance to be running during the test, we fake it using WireMock.

One benefit of using web service fakes in testing is to inject faulty behavior that might be difficult to simulate in the real service. In addition to being able to send back any HTTP response code indicating an error, WireMock is able to generate a few other types of problem.

For example, you can instruct WireMock to not return a response until after a fixed delay has passed:

```Java
stubFor(get(urlEqualTo("/delayed")).willReturn(
        aResponse()
                .withStatus(200)
                .withFixedDelay(2000)));
```

## Add Testing of Ticket Monster Circuit Breaking

Now lets add integration testing of our Circuit Breaking abilities.

### Test the Sending of Messages in User-Service

#### Setup a Fake Slow Service

Add the following Rule setup function to the **order-service** `OrderIntegrationServiceTest` class:

```java
	private void setupRuleForDelayedResponse(WireMockRule wireMockRule) {
		wireMockRule
                .stubFor(get(WireMock.urlMatching("/users/[0-9]+"))
                        .willReturn(
                                aResponse()
                                        .withStatus(404)
                                        .withFixedDelay(5000)
                        )
                );
	}
```

##### What do these changes do?

This code uses WireMock to setup a fake **user-service** instance which takes 5 seconds to respond to a URL such as http://localhost9090/users/0

#### Add A Message Sending Integration Test

Add the following test functions to the **order-service** `OrderIntegrationServiceTest` class:

```java
    @Test
    public void placeOrder() throws Exception {
    	
        setupRuleToReturnUser(wireMockRule9090);

        OrderDetails mockOrderDetails = new OrderDetails("eventTitle", LocalDateTime.now(), "venue1", 2);
        HttpEntity<OrderDetails> entity = new HttpEntity<OrderDetails>(mockOrderDetails,headers);

        final ResponseEntity<Order> responseEntity = this.restTemplate.exchange(
                hostName + ":" + PORT + "/orders", HttpMethod.POST, entity, new ParameterizedTypeReference<Order>() {});

        Assert.assertEquals("PENDING",responseEntity.getBody().getOrderStatus());
        Assert.assertEquals(201, responseEntity.getStatusCodeValue());
    }
    
    @Test
    public void placeOrderNoResponseFromUserService() throws Exception {
    	
        setupRuleForDelayedResponse(wireMockRule9090);

        OrderDetails mockOrderDetails = new OrderDetails("eventTitle", LocalDateTime.now(), "venue1", 2);
        HttpEntity<OrderDetails> entity = new HttpEntity<OrderDetails>(mockOrderDetails,headers);

        final ResponseEntity<Order> responseEntity = this.restTemplate.exchange(
                hostName + ":" + PORT + "/orders", HttpMethod.POST, entity, new ParameterizedTypeReference<Order>() {});

        Assert.assertEquals("UNCONFIRMED",responseEntity.getBody().getOrderStatus());
        Assert.assertEquals(201, responseEntity.getStatusCodeValue());
    }

```

Add the necessary imports as well.

##### What do these changes do?

The first function tests that placing an order with a normal, undelayed fake **user-service**  creates  the order with the `PENDING` status.

The second function tests that placing an order with a delayed fake **user-service** which simulates an unresponsive service creates the order with the `UNCONFIRMED` status. It sets up the fake slow service by calling `setupRuleForDelayedResponse`.

Both services use Spring's ability to inject a test version of `RestTemplate` during integration tests. Because placing an order requires HTTP POST and headers in the POST request, the tests use the function `restTemplate.exchange` to send the values. Now we just need to add the headers.

#### Add Setup Code For Adding Headers to All Tests

In the **order-service** `OrderIntegrationServiceTest` class add the line `headers.add("userID", "0");` to the `setUP` function of the **order-service** `OrderIntegrationServiceTest` class:

```java
    @Before
    public void setUp() {
        headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.add("userID", "0");
```

##### What do these changes do?

A place-order HTTP post request must contain the `userID` for the order in the header of the request. The test for `getAllOrders` already added this header, but now that we have 2 new test functions that need it, it is a good idea to move it from there to the test `setUp` function.

#### Change the getAllOrders Test to Match The Changes

In the **order-service** `OrderIntegrationServiceTest` class add, remove the `headers.add("userID", "0")` line from the `getAllOrders` test. Then add the following line to set up the rule to set up an non-delayed service

```java
@Test
public void getAllOrders() throws Exception {
	
    //headers.add("userID", "0");
    setupRuleToReturnUser(wireMockRule9090);
```
##### What do these changes do?

Now that we have two different functions to setup a fake **user-service** we need to choose the right one. `getAllOrders` needs to call the function to setup the standard, undelayed fake **user-service**. The line for adding the `userID` header has been added to the setUp function which is called before each test, so we don't want it here anymore.

#### Add Test Data Cleanup Functions

In the **order-service** `OrderIntegrationServiceTest` class add , add the following functions and member

```java
	@Autowired
	protected OrderRepository orderRepository;

	@Before
	public void deleteAll(){
		orderRepository.deleteAll();
	}
	
	@After
	public void deleteTestDataAfterTest(){
		orderRepository.deleteAll(); 
	}
```

##### What do these changes do?

Now that you added two test functions that place orders in the database, the tests should clean up after themselves and delete the orders so they don't interfere with other tests.

#### Your Completed Integration Test Code

This is what your completed **order-service** `OrderIntegrationServiceTest` test class should look like after all the changes:

```java
package org.amdocs.elearning.order.service.order;

import java.time.LocalDateTime;
import java.util.List;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockRule;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;

import org.amdocs.elearning.order.service.Application;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;


@RunWith(SpringRunner.class)
@SpringBootTest(
        classes = Application.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {
                "service.user.port=9090",
                "service.user.hostname=http://localhost",
                "spring.profiles.active=Production"
        }
)
public class OrderIntegrationServiceTest {
    private HttpHeaders headers;

    @Value("${service.user.hostname}")
    private String hostName;

    @Value("${service.user.port}")
    private int userPort;

    @LocalServerPort
    private int PORT;

    @Autowired
    private TestRestTemplate restTemplate;

    @Rule
    public WireMockRule wireMockRule9090 = new WireMockRule(9090);
    //@Rule
    //public WireMockRule wireMockRule9091 = new WireMockRule(9091);
    //@Rule
    //public WireMockRule wireMockRule9092 = new WireMockRule(9092);

	@Autowired
	protected OrderRepository orderRepository;


    @Before
    public void setUp() {
        headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.add("userID", "0");

        setupRuleForPingToRoot(wireMockRule9090);
        //setupRuleForPingToRoot(wireMockRule9091);
        //setupRuleForPingToRoot(wireMockRule9092);

        
        setupRuleToReturnUser(wireMockRule9090);
        //setupRuleToReturnUser(wireMockRule9091);
        //setupRuleToReturnUser(wireMockRule9092);

    }
    
	@Before
	public void deleteAll(){
		orderRepository.deleteAll();
	}
	
	@After
	public void deleteTestDataAfterTest(){
		orderRepository.deleteAll(); 
	}



	private void setupRuleToReturnUser(WireMockRule wireMockRule) {
		wireMockRule
                .stubFor(get(WireMock.urlMatching("/users/[0-9]+"))
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withHeader("Content-Type", "application/json")
                                        .withHeader("content-type", "application/json")
                                        .withBody("{" +
                                                "\"id\":\"1235\"," +
                                                "\"firstName\":\"first\"," +
                                                "\"lastName\":\"last\"," +
                                                "\"middleInitial\":\"middle\"," +
                                                "\"userType\":\"PATRON\"" +
                                                "}")
                        )
                );
	}

	private void setupRuleForDelayedResponse(WireMockRule wireMockRule) {
		wireMockRule
                .stubFor(get(WireMock.urlMatching("/users/[0-9]+"))
                        .willReturn(
                                aResponse()
                                        .withStatus(404)
                                        .withFixedDelay(5000)
                        )
                );
	}
	
	private void setupRuleForPingToRoot(WireMockRule wireMockRule) {
		wireMockRule
        .stubFor(get(WireMock.urlMatching("/"))
                .willReturn(
                        aResponse()
                                .withStatus(200)
                )
        );
	}

    @Test
    public void getAllOrders() throws Exception {
        setupRuleToReturnUser(wireMockRule9090);

        HttpEntity<Object> entity = new HttpEntity<Object>(headers);

        final ResponseEntity<List<Order>> responseEntity = this.restTemplate.exchange(
                hostName + ":" + PORT + "/orders", HttpMethod.GET, entity, new ParameterizedTypeReference<List<Order>>() {});

        Assert.assertEquals(200, responseEntity.getStatusCodeValue());
        Assert.assertNotNull(responseEntity.getBody());
    }
    
    @Test
    public void placeOrder() throws Exception {
    	
        setupRuleToReturnUser(wireMockRule9090);

        OrderDetails mockOrderDetails = new OrderDetails("eventTitle", LocalDateTime.now(), "venue1", 2);
        HttpEntity<OrderDetails> entity = new HttpEntity<OrderDetails>(mockOrderDetails,headers);

        final ResponseEntity<Order> responseEntity = this.restTemplate.exchange(
                hostName + ":" + PORT + "/orders", HttpMethod.POST, entity, new ParameterizedTypeReference<Order>() {});

        Assert.assertEquals("PENDING",responseEntity.getBody().getOrderStatus());
        Assert.assertEquals(201, responseEntity.getStatusCodeValue());
    }
    
    @Test
    public void placeOrderNoResponseFromUserService() throws Exception {
    	
        setupRuleForDelayedResponse(wireMockRule9090);

        OrderDetails mockOrderDetails = new OrderDetails("eventTitle", LocalDateTime.now(), "venue1", 2);
        HttpEntity<OrderDetails> entity = new HttpEntity<OrderDetails>(mockOrderDetails,headers);

        final ResponseEntity<Order> responseEntity = this.restTemplate.exchange(
                hostName + ":" + PORT + "/orders", HttpMethod.POST, entity, new ParameterizedTypeReference<Order>() {});

        Assert.assertEquals("UNCONFIRMED",responseEntity.getBody().getOrderStatus());
        Assert.assertEquals(201, responseEntity.getStatusCodeValue());
    }

}
```





## Building and Running Tests

### Build and Run the Order Service Tests

Make sure you save your work. Then, build and run the **order-service** tests:

1. In a Terminal, change to the **md205/sandbox/order-service** directory.

2. Package the application with: `mvn clean package`

   Make sure that all the unit and integration tests passed, that there were no failures or errors, and that Maven terminated with a `[INFO] BUILD SUCCESS` message

   

Did all the tests pass? Perfect! You just used Spring Integration testing to test how your code handles a slow service, and if the Hystrix implemented Circuit Breaker works correctly

Nice job!!

![ThumbsUp](images/thumbsup.png)

## Summary

In this step you added testing for Ticket Monster's new Circuit Breaking code. You checked that it places an order with a temporary status when Hystrix returns a fallback value instead of actually calling **user-service**.

You have now successfully completed the Hystrix and Circuit Breaking chapter, and - 

you have also successfully completed the advanced Microservices course!

Congratulations. Give yourself a pat on the shoulder for all your great work!

_**Want to learn more?** See the "Dive Deeper" section in the chapter introduction (Jam page) for links to articles and videos about the topics in this chapter._