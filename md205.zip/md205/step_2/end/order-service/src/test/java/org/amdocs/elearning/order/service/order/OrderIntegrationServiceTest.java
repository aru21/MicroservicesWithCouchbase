package org.amdocs.elearning.order.service.order;

import java.time.LocalDateTime;
import java.util.List;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockRule;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;

import org.amdocs.elearning.order.service.Application;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;


@RunWith(SpringRunner.class)
@SpringBootTest(
        classes = Application.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {
                "service.user.port=9090",
                "service.user.hostname=http://localhost",
                "spring.profiles.active=Production"
        }
)
public class OrderIntegrationServiceTest {
    private HttpHeaders headers;

    @Value("${service.user.hostname}")
    private String hostName;

    @Value("${service.user.port}")
    private int userPort;

    @LocalServerPort
    private int PORT;

    @Autowired
    private TestRestTemplate restTemplate;

    @Rule
    public WireMockRule wireMockRule9090 = new WireMockRule(9090);
    //@Rule
    //public WireMockRule wireMockRule9091 = new WireMockRule(9091);
    //@Rule
    //public WireMockRule wireMockRule9092 = new WireMockRule(9092);

	@Autowired
	protected OrderRepository orderRepository;


    @Before
    public void setUp() {
        headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.add("userID", "0");

        setupRuleForPingToRoot(wireMockRule9090);
        //setupRuleForPingToRoot(wireMockRule9091);
        //setupRuleForPingToRoot(wireMockRule9092);

        
        setupRuleToReturnUser(wireMockRule9090);
        //setupRuleToReturnUser(wireMockRule9091);
        //setupRuleToReturnUser(wireMockRule9092);

    }
    
	@Before
	public void deleteAll(){
		orderRepository.deleteAll();
	}
	
	@After
	public void deleteTestDataAfterTest(){
		orderRepository.deleteAll(); 
	}



	private void setupRuleToReturnUser(WireMockRule wireMockRule) {
		wireMockRule
                .stubFor(get(WireMock.urlMatching("/users/[0-9]+"))
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withHeader("Content-Type", "application/json")
                                        .withHeader("content-type", "application/json")
                                        .withBody("{" +
                                                "\"id\":\"1235\"," +
                                                "\"firstName\":\"first\"," +
                                                "\"lastName\":\"last\"," +
                                                "\"middleInitial\":\"middle\"," +
                                                "\"userType\":\"PATRON\"" +
                                                "}")
                        )
                );
	}

	private void setupRuleForDelayedResponse(WireMockRule wireMockRule) {
		wireMockRule
                .stubFor(get(WireMock.urlMatching("/users/[0-9]+"))
                        .willReturn(
                                aResponse()
                                        .withStatus(404)
                                        .withFixedDelay(5000)
                        )
                );
	}
	
	private void setupRuleForPingToRoot(WireMockRule wireMockRule) {
		wireMockRule
        .stubFor(get(WireMock.urlMatching("/"))
                .willReturn(
                        aResponse()
                                .withStatus(200)
                )
        );
	}

    @Test
    public void getAllOrders() throws Exception {
        setupRuleToReturnUser(wireMockRule9090);

        HttpEntity<Object> entity = new HttpEntity<Object>(headers);

        final ResponseEntity<List<Order>> responseEntity = this.restTemplate.exchange(
                hostName + ":" + PORT + "/orders", HttpMethod.GET, entity, new ParameterizedTypeReference<List<Order>>() {});

        Assert.assertEquals(200, responseEntity.getStatusCodeValue());
        Assert.assertNotNull(responseEntity.getBody());
    }
    
    @Test
    public void placeOrder() throws Exception {
    	
        setupRuleToReturnUser(wireMockRule9090);

        OrderDetails mockOrderDetails = new OrderDetails("eventTitle", LocalDateTime.now(), "venue1", 2);
        HttpEntity<OrderDetails> entity = new HttpEntity<OrderDetails>(mockOrderDetails,headers);

        final ResponseEntity<Order> responseEntity = this.restTemplate.exchange(
                hostName + ":" + PORT + "/orders", HttpMethod.POST, entity, new ParameterizedTypeReference<Order>() {});

        Assert.assertEquals("PENDING",responseEntity.getBody().getOrderStatus());
        Assert.assertEquals(201, responseEntity.getStatusCodeValue());
    }
    
    @Test
    public void placeOrderNoResponseFromUserService() throws Exception {
    	
        setupRuleForDelayedResponse(wireMockRule9090);

        OrderDetails mockOrderDetails = new OrderDetails("eventTitle", LocalDateTime.now(), "venue1", 2);
        HttpEntity<OrderDetails> entity = new HttpEntity<OrderDetails>(mockOrderDetails,headers);

        final ResponseEntity<Order> responseEntity = this.restTemplate.exchange(
                hostName + ":" + PORT + "/orders", HttpMethod.POST, entity, new ParameterizedTypeReference<Order>() {});

        Assert.assertEquals("UNCONFIRMED",responseEntity.getBody().getOrderStatus());
        Assert.assertEquals(201, responseEntity.getStatusCodeValue());
    }

}